package com.robsondev.cursosji;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursosjiApplicationTests {

	@Test
	void contextLoads() {
	}

}
